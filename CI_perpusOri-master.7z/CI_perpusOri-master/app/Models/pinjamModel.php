<?php

namespace App\Models;

use CodeIgniter\Model;

class pinjamModel extends Model
{
    protected $table = 'peminjaman';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id_anggota', 'id_buku', 'tanggal_peminjaman', 'tanggal_pengembalian'];
    protected $returnType = 'array';
    public function getPeminjaman()
    {
        return $this->findAll();
    }
}