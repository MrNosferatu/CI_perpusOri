<footer class="bg-dark text-white p-3">
<div class="text-center">
<img src="https://upload.wikimedia.org/wikipedia/en/7/7a/Manchester_United_FC_crest.svg" alt="Manchester United Logo" height="50">
<p class="mb-0">Developed by Fhadwa N</p>
</div>
</footer>
</body>
</html>