<table id="tabel-peminjaman">
  <tr>
    <th>Name</th>
    <th>Buku</th>
    <th>Tanggal Peminjaman</th>
    <th>Denda</th>
    <th>Pengembalian</th>
  </tr>
  <?php foreach ($peminjaman as $row) : ?>
    <tr>
      <td><?= $row['id_anggota'] ?></td>
      <td><?= $row['id_buku'] ?></td>
      <td><?= $row['tanggal_peminjaman'] ?></td>
      <td><?= $row['denda'] ?></td>
      <td>
      <a href="/kembali/id=<?= $row['id'] ?>">Pengembalian<button>
      </td>
    </tr>
  <?php endforeach ?>
</table>